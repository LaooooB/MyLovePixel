using Avalonia;
using Avalonia.Controls;
using Avalonia.Media;
using Avalonia.Styling;

namespace MyLovePixel.Desktop;

public static class EditorStyles
{
    public static void Apply(Avalonia.Application app)
    {
        ArgumentNullException.ThrowIfNull(app);

        app.Styles.Add(new Style(x => x.OfType<Button>())
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, EditorThemeTokens.SurfaceRaised),
                new Setter(Button.ForegroundProperty, EditorThemeTokens.TextPrimary),
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.PanelBorder),
                new Setter(Button.BorderThicknessProperty, new Thickness(1)),
                new Setter(Button.CornerRadiusProperty, EditorThemeTokens.ControlRadius),
                new Setter(Button.PaddingProperty, new Thickness(10, 5)),
                new Setter(Button.FontSizeProperty, 12d),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class(":pointerover"))
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, EditorThemeTokens.SurfaceHover),
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.StrongBorder),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class(":focus"))
        {
            Setters =
            {
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.Accent),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class(":disabled"))
        {
            Setters =
            {
                new Setter(Button.OpacityProperty, 0.42d),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class("compact"))
        {
            Setters =
            {
                new Setter(Button.PaddingProperty, new Thickness(8, 3)),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class("ghost"))
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, Brushes.Transparent),
                new Setter(Button.BorderBrushProperty, Brushes.Transparent),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class("ghost").Class(":pointerover"))
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, EditorThemeTokens.SurfaceHover),
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.PanelBorder),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class("primary"))
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, EditorThemeTokens.Accent),
                new Setter(Button.ForegroundProperty, EditorThemeTokens.AccentForeground),
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.Accent),
                new Setter(Button.FontWeightProperty, FontWeight.SemiBold),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class("primary").Class(":pointerover"))
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, EditorThemeTokens.AccentHover),
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.AccentHover),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class("selected"))
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, EditorThemeTokens.SurfaceSelected),
                new Setter(Button.ForegroundProperty, EditorThemeTokens.Accent),
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.Accent),
                new Setter(Button.FontWeightProperty, FontWeight.SemiBold),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<Button>().Class("selected").Class(":pointerover"))
        {
            Setters =
            {
                new Setter(Button.BackgroundProperty, EditorThemeTokens.SurfaceSelected),
                new Setter(Button.BorderBrushProperty, EditorThemeTokens.AccentHover),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<TextBlock>())
        {
            Setters =
            {
                new Setter(TextBlock.ForegroundProperty, EditorThemeTokens.TextPrimary),
                new Setter(TextBlock.FontSizeProperty, 12d),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<TextBlock>().Class("muted"))
        {
            Setters =
            {
                new Setter(TextBlock.ForegroundProperty, EditorThemeTokens.TextSecondary),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<TextBlock>().Class("subtle"))
        {
            Setters =
            {
                new Setter(TextBlock.ForegroundProperty, EditorThemeTokens.TextMuted),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<TextBlock>().Class("accent"))
        {
            Setters =
            {
                new Setter(TextBlock.ForegroundProperty, EditorThemeTokens.Accent),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<TextBlock>().Class("danger"))
        {
            Setters =
            {
                new Setter(TextBlock.ForegroundProperty, EditorThemeTokens.Danger),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<TextBlock>().Class("section-title"))
        {
            Setters =
            {
                new Setter(TextBlock.ForegroundProperty, EditorThemeTokens.TextPrimary),
                new Setter(TextBlock.FontWeightProperty, FontWeight.SemiBold),
                new Setter(TextBlock.FontSizeProperty, 12d),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<ComboBox>())
        {
            Setters =
            {
                new Setter(ComboBox.BackgroundProperty, EditorThemeTokens.SurfaceRaised),
                new Setter(ComboBox.ForegroundProperty, EditorThemeTokens.TextPrimary),
                new Setter(ComboBox.BorderBrushProperty, EditorThemeTokens.PanelBorder),
                new Setter(ComboBox.BorderThicknessProperty, new Thickness(1)),
                new Setter(ComboBox.CornerRadiusProperty, EditorThemeTokens.ControlRadius),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<ComboBox>().Class(":focus"))
        {
            Setters =
            {
                new Setter(ComboBox.BorderBrushProperty, EditorThemeTokens.Accent),
            },
        });

        app.Styles.Add(new Style(x => x.OfType<CheckBox>())
        {
            Setters =
            {
                new Setter(CheckBox.ForegroundProperty, EditorThemeTokens.TextPrimary),
                new Setter(CheckBox.FontSizeProperty, 12d),
            },
        });
    }
}
