using Avalonia;
using Avalonia.Media;

namespace MyLovePixel.Desktop;

public static class EditorThemeTokens
{
    // Core surfaces. Keep the editor dark and quiet so artwork stays visually dominant.
    public static IBrush AppBackground { get; } = Rgb(12, 13, 16);
    public static IBrush Surface { get; } = Rgb(18, 20, 25);
    public static IBrush SurfaceRaised { get; } = Rgb(24, 27, 34);
    public static IBrush SurfaceHover { get; } = Rgb(31, 36, 44);
    public static IBrush SurfaceSelected { get; } = Rgb(23, 50, 47);
    public static IBrush CanvasBackground { get; } = Rgb(10, 11, 14);
    public static IBrush CanvasFrame { get; } = Rgb(20, 22, 27);

    // Borders and separators.
    public static IBrush PanelBorder { get; } = Rgb(45, 50, 60);
    public static IBrush StrongBorder { get; } = Rgb(69, 78, 91);

    // Typography.
    public static IBrush TextPrimary { get; } = Rgb(236, 241, 247);
    public static IBrush TextSecondary { get; } = Rgb(162, 172, 185);
    public static IBrush TextMuted { get; } = Rgb(111, 120, 132);

    // Bright colors are intentionally reserved for important interaction/state.
    public static IBrush Accent { get; } = Rgb(99, 230, 205);
    public static IBrush AccentHover { get; } = Rgb(129, 239, 219);
    public static IBrush AccentForeground { get; } = Rgb(6, 24, 22);
    public static IBrush Warning { get; } = Rgb(241, 196, 95);
    public static IBrush Danger { get; } = Rgb(255, 105, 121);

    // Pixel-canvas specific colors.
    public static IBrush CheckerLight { get; } = Rgb(74, 79, 87);
    public static IBrush CheckerDark { get; } = Rgb(55, 60, 67);
    public static IBrush PreviewOutline { get; } = Accent;
    public static IBrush DirtyRegionOutline { get; } = Danger;

    public static CornerRadius ControlRadius { get; } = new(6);
    public static CornerRadius CardRadius { get; } = new(8);

    public const double CompactSpacing = 4d;
    public const double ControlSpacing = 6d;
    public const double PanelSpacing = 10d;
    public const double SectionSpacing = 12d;
    public const double ShellPadding = 10d;

    public const double LeftPanelWidth = 236d;
    public const double RightPanelWidth = 300d;
    public const double TimelineHeight = 140d;

    private static IBrush Rgb(byte r, byte g, byte b) =>
        new SolidColorBrush(Color.FromRgb(r, g, b));
}
