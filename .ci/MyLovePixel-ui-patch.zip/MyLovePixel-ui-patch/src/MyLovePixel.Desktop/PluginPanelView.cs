using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Layout;
using Avalonia.Media;
using MyLovePixel.Application;

namespace MyLovePixel.Desktop;

public sealed class PluginPanelView : ScrollViewer
{
    private readonly StackPanel _content = new()
    {
        Spacing = EditorThemeTokens.PanelSpacing,
        Margin = new Thickness(EditorThemeTokens.ShellPadding),
    };

    public PluginPanelView()
    {
        Background = EditorThemeTokens.AppBackground;
        Content = _content;
        HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
    }

    public void SetPanels(
        IReadOnlyList<PluginPanelPresentation> panels,
        Func<string, string, PluginPanelActionResult>? invoke = null)
    {
        ArgumentNullException.ThrowIfNull(panels);
        _content.Children.Clear();

        if (panels.Count == 0)
        {
            var empty = new TextBlock
            {
                Text = "No plugin panels",
                Margin = new Thickness(2),
            };
            empty.Classes.Add("subtle");
            _content.Children.Add(empty);
            return;
        }

        foreach (var panel in panels)
        {
            var panelContent = new StackPanel { Spacing = EditorThemeTokens.ControlSpacing };
            foreach (var section in panel.Sections)
            {
                var sectionContent = new StackPanel { Spacing = EditorThemeTokens.CompactSpacing };

                foreach (var field in section.Fields)
                {
                    var row = new Grid { ColumnDefinitions = new ColumnDefinitions("Auto,*") };
                    var label = new TextBlock
                    {
                        Text = field.Label,
                        Margin = new Thickness(0, 0, 10, 0),
                    };
                    label.Classes.Add("subtle");
                    row.Children.Add(label);

                    var value = new TextBlock
                    {
                        Text = field.Value,
                        TextWrapping = TextWrapping.Wrap,
                    };
                    Grid.SetColumn(value, 1);
                    row.Children.Add(value);
                    sectionContent.Children.Add(row);
                }

                foreach (var action in section.Actions)
                {
                    var button = new Button
                    {
                        Content = action.Label,
                        IsEnabled = action.Enabled && invoke is not null,
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                    };
                    if (invoke is not null)
                    {
                        var capturedPanel = panel.Id;
                        var capturedAction = action.Id;
                        button.Click += (_, _) => invoke(capturedPanel, capturedAction);
                    }
                    sectionContent.Children.Add(button);
                }

                panelContent.Children.Add(BuildSection(section.Title, sectionContent));
            }

            _content.Children.Add(BuildPanel(panel.Title, panelContent));
        }
    }

    private static Border BuildPanel(string title, Control content)
    {
        var root = new StackPanel { Spacing = EditorThemeTokens.ControlSpacing };
        var titleBlock = new TextBlock
        {
            Text = title,
            FontWeight = FontWeight.SemiBold,
        };
        titleBlock.Classes.Add("section-title");
        root.Children.Add(titleBlock);
        root.Children.Add(content);

        return new Border
        {
            Background = EditorThemeTokens.Surface,
            BorderBrush = EditorThemeTokens.PanelBorder,
            BorderThickness = new Thickness(1),
            CornerRadius = EditorThemeTokens.CardRadius,
            Padding = new Thickness(10),
            Child = root,
        };
    }

    private static Border BuildSection(string title, Control content)
    {
        var root = new StackPanel { Spacing = EditorThemeTokens.CompactSpacing };
        var titleBlock = new TextBlock { Text = title };
        titleBlock.Classes.Add("muted");
        root.Children.Add(titleBlock);
        root.Children.Add(content);

        return new Border
        {
            Background = EditorThemeTokens.SurfaceRaised,
            BorderBrush = EditorThemeTokens.PanelBorder,
            BorderThickness = new Thickness(1),
            CornerRadius = EditorThemeTokens.ControlRadius,
            Padding = new Thickness(8),
            Child = root,
        };
    }
}
