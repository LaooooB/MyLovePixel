# MyLovePixel UI optimization patch

This patch only changes the desktop presentation layer. It does not change editor business logic, persistence formats, command behavior, rendering data, recovery policy, or GitHub state.

Replace/copy these files into `src/MyLovePixel.Desktop/`:

- `EditorThemeTokens.cs`
- `EditorStyles.cs` (new)
- `Program.cs`
- `MainWindow.cs`
- `PluginPanelView.cs`
- `PixelCanvasView.cs`

Design rules applied:

- Dark theme is forced at application level.
- All custom colors are centralized as semantic tokens.
- Bright accent is reserved for primary action, selected tool/layer/frame, focus and recovery action.
- Errors use a dedicated danger semantic color.
- Panels use consistent card composition and spacing.
- Empty/error states use shared presentation helpers rather than ad-hoc styling.
- Existing native Avalonia controls remain in use instead of custom control reinvention.

Validation performed in this environment:

- Reviewed all custom UI source files in `MyLovePixel.Desktop` from the repository.
- Checked replacement C# files for balanced delimiters/strings.
- No .NET SDK is installed in the execution environment, so a real `dotnet build` could not be run here.
