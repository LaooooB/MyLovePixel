using System.Runtime.CompilerServices;
using MyLovePixel.Animation;
using MyLovePixel.Commands.Color;
using MyLovePixel.Commands.Document;
using MyLovePixel.Commands.Effects;
using MyLovePixel.Commands.Pixel;
using MyLovePixel.Commands.Resources;
using MyLovePixel.Commands.Tiles;
using MyLovePixel.Commands.Timeline;
using MyLovePixel.Core.Document;
using MyLovePixel.Core.Effects;
using MyLovePixel.Core.Pixel;
using MyLovePixel.Core.Primitives;
using MyLovePixel.Core.Tiles;
using MyLovePixel.Effects;
using MyLovePixel.Export;
using MyLovePixel.Persistence;
using MyLovePixel.Render;
using MyLovePixel.Selection;

namespace MyLovePixel.Application;

public sealed record SelectionOverlayPresentation(IntRect Bounds, IReadOnlyList<IntPoint> Pixels);
public sealed record EffectItemPresentation(EffectInstanceId Id, string TypeId, string DisplayName, bool Enabled, int Index);
public sealed record EffectParameterPresentation(string Key, string DisplayName, EffectParameterKind Kind, EffectValue Value, double? Minimum, double? Maximum, bool Animatable, bool HasKeyframe);
public sealed record TilesetPresentation(TilesetId Id, string Name, IntSize TileSize, int TileCount);
public sealed record TilePresentation(TileId Id, string Name, ResourceId SurfaceId, bool IsCurrent);
public sealed record TilemapPresentation(TilemapId Id, string Name, TilesetId TilesetId, int OccupiedCellCount);
public sealed record AnimationClipPresentation(AnimationClipId Id, string Name, int Start, int End, AnimationLoopMode LoopMode);
public sealed record AnimationTagPresentation(AnimationTagId Id, string Name, int Start, int End);
public sealed record AnimationTracksPresentation(bool HasPivot, int HitboxCount, int HurtboxCount, int SocketCount, int EventCount, int ColorCycleCount);
public sealed record OnionSkinPresentationSettings(int PreviousFrames = 1, int NextFrames = 1, byte Opacity = 96, double DepthFalloff = 0.65);
public sealed record TileSurfacePresentation(IntSize Size, PixelFormat Format, PaletteId? PaletteId, ReadOnlyMemory<byte> Bytes);

public static class AdvancedEditingExtensions
{
    private static readonly EffectRegistry Effects = EffectRegistry.CreateDefault();

    public static LayerId AddLayer(this DocumentSession session, string? name = null)
    {
        ArgumentNullException.ThrowIfNull(session);
        var command = new AddPixelLayerCommand(name ?? $"Layer {session.GetLayers().Count + 1}", session.CurrentFrameId);
        session.Execute(command);
        session.SelectLayer(command.LayerId);
        return command.LayerId;
    }

    public static void RemoveCurrentLayer(this DocumentSession session)
    {
        ArgumentNullException.ThrowIfNull(session);
        var order = session.CaptureSnapshot().LayerOrder;
        if (order.Count <= 1) return;
        var oldIndex = order.ToList().IndexOf(session.CurrentLayerId);
        var next = order[oldIndex == 0 ? 1 : oldIndex - 1];
        session.Execute(new RemoveLayerCommand(session.CurrentLayerId));
        session.SelectLayer(next);
    }

    public static void MoveCurrentLayer(this DocumentSession session, int delta)
    {
        ArgumentNullException.ThrowIfNull(session);
        var snapshot = session.CaptureSnapshot();
        var oldIndex = snapshot.LayerOrder.ToList().IndexOf(session.CurrentLayerId);
        var next = Math.Clamp(oldIndex + delta, 0, snapshot.LayerOrder.Count - 1);
        if (next != oldIndex) session.Execute(new MoveLayerCommand(session.CurrentLayerId, next));
    }

    public static void EnsureEditableCel(this DocumentSession session)
    {
        ArgumentNullException.ThrowIfNull(session);
        if (session.HasEditableCel) return;
        session.Execute(new EnsureCelCommand(session.CurrentLayerId, session.CurrentFrameId));
    }

    public static FrameId DuplicateCurrentFrame(this DocumentSession session, bool linked)
    {
        ArgumentNullException.ThrowIfNull(session);
        var command = new CopyFrameCommand(session.CurrentFrameId, linked ? FrameCopyMode.Linked : FrameCopyMode.Independent);
        session.Execute(command);
        session.SelectFrame(command.NewFrameId);
        return command.NewFrameId;
    }

    public static void RemoveCurrentFrame(this DocumentSession session)
    {
        ArgumentNullException.ThrowIfNull(session);
        var snapshot = session.CaptureSnapshot();
        if (snapshot.FrameOrder.Count <= 1) return;
        var oldIndex = snapshot.FrameOrder.ToList().IndexOf(session.CurrentFrameId);
        var next = snapshot.FrameOrder[oldIndex == 0 ? 1 : oldIndex - 1];
        session.Execute(new RemoveFrameCommand(session.CurrentFrameId));
        session.SelectFrame(next);
    }

    public static void MoveCurrentFrame(this DocumentSession session, int delta)
    {
        ArgumentNullException.ThrowIfNull(session);
        var snapshot = session.CaptureSnapshot();
        var oldIndex = snapshot.FrameOrder.ToList().IndexOf(session.CurrentFrameId);
        var next = Math.Clamp(oldIndex + delta, 0, snapshot.FrameOrder.Count - 1);
        if (next != oldIndex) session.Execute(new MoveFrameCommand(session.CurrentFrameId, next));
    }

    public static void SetCurrentFrameDuration(this DocumentSession session, long durationTicks)
    {
        ArgumentNullException.ThrowIfNull(session);
        var current = session.CaptureSnapshot().GetFrame(session.CurrentFrameId).DurationTicks;
        if (current == durationTicks) return;
        session.Execute(new SetFrameDurationCommand(session.CurrentFrameId, durationTicks));
    }

    public static Rgba32 GetCanvasPixel(this DocumentSession session, int canvasX, int canvasY)
    {
        ArgumentNullException.ThrowIfNull(session);
        var snapshot = session.CaptureSnapshot();
        var cel = snapshot.Cels.FirstOrDefault(value => value.LayerId == session.CurrentLayerId && value.FrameId == session.CurrentFrameId)
            ?? throw new InvalidOperationException("Current Layer/Frame has no Cel.");
        var local = new IntPoint(canvasX - cel.Position.X, canvasY - cel.Position.Y);
        var surface = snapshot.GetSurface(cel.SurfaceId);
        if ((uint)local.X >= (uint)surface.Size.Width || (uint)local.Y >= (uint)surface.Size.Height) return Rgba32.Transparent;
        return surface.GetPixel(local.X, local.Y);
    }

    public static IReadOnlyList<EffectItemPresentation> GetCurrentEffects(this DocumentSession session)
    {
        ArgumentNullException.ThrowIfNull(session);
        var snapshot = session.CaptureSnapshot();
        var cel = snapshot.Cels.FirstOrDefault(value => value.LayerId == session.CurrentLayerId && value.FrameId == session.CurrentFrameId);
        if (cel is null) return [];
        return cel.Effects.EffectOrder.Select((id, index) =>
        {
            var value = cel.Effects.GetEffect(id);
            var display = Effects.TryGetDescriptor(value.TypeId, out var descriptor) ? descriptor.DisplayName : value.TypeId;
            return new EffectItemPresentation(id, value.TypeId, display, value.Enabled, index);
        }).ToArray();
    }

    public static IReadOnlyList<EffectParameterPresentation> GetEffectParameters(this DocumentSession session, EffectInstanceId effectId)
    {
        ArgumentNullException.ThrowIfNull(session);
        var snapshot = session.CaptureSnapshot();
        var cel = snapshot.Cels.First(value => value.LayerId == session.CurrentLayerId && value.FrameId == session.CurrentFrameId);
        var effect = cel.Effects.GetEffect(effectId);
        if (!Effects.TryGetDescriptor(effect.TypeId, out var descriptor)) return [];
        return descriptor.Parameters.Values.Select(parameter =>
        {
            effect.TryResolveParameter(parameter.Key, session.CurrentFrameId, descriptor, out var value);
            var hasKeyframe = effect.ParameterTracks.TryGetValue(parameter.Key, out var track) && track.Values.ContainsKey(session.CurrentFrameId);
            return new EffectParameterPresentation(parameter.Key, parameter.DisplayName, parameter.Kind, value, parameter.Minimum, parameter.Maximum, parameter.Animatable, hasKeyframe);
        }).ToArray();
    }

    public static IReadOnlyList<string> GetBuiltinEffectTypes() => Effects.TypeIds.OrderBy(value => value, StringComparer.Ordinal).ToArray();

    public static EffectInstanceId AddEffect(this DocumentSession session, string typeId)
    {
        ArgumentNullException.ThrowIfNull(session);
        Effects.GetDescriptor(typeId);
        var cel = ResolveCurrentCel(session);
        var command = new AddEffectCommand(cel.Id, typeId);
        session.Execute(command);
        return command.EffectId;
    }

    public static void RemoveEffect(this DocumentSession session, EffectInstanceId effectId)
    {
        var cel = ResolveCurrentCel(session);
        session.Execute(new RemoveEffectCommand(cel.Id, effectId));
    }

    public static void MoveEffect(this DocumentSession session, EffectInstanceId effectId, int delta)
    {
        var cel = ResolveCurrentCel(session);
        var order = cel.Effects.EffectOrder;
        var index = order.ToList().IndexOf(effectId);
        var next = Math.Clamp(index + delta, 0, order.Count - 1);
        if (next != index) session.Execute(new MoveEffectCommand(cel.Id, effectId, next));
    }

    public static void SetEffectEnabled(this DocumentSession session, EffectInstanceId effectId, bool enabled)
    {
        var cel = ResolveCurrentCel(session);
        session.Execute(new SetEffectEnabledCommand(cel.Id, effectId, enabled));
    }

    public static void SetEffectParameter(this DocumentSession session, EffectInstanceId effectId, string key, EffectValue value)
    {
        var cel = ResolveCurrentCel(session);
        var effect = cel.Effects.GetEffect(effectId);
        var descriptor = Effects.GetDescriptor(effect.TypeId);
        session.Execute(new SetEffectParameterCommand(cel.Id, effectId, key, value, descriptor));
    }


    public static void SetEffectParameterKeyframe(this DocumentSession session, EffectInstanceId effectId, string key, EffectValue value)
    {
        var cel = ResolveCurrentCel(session);
        var effect = cel.Effects.GetEffect(effectId);
        var descriptor = Effects.GetDescriptor(effect.TypeId);
        session.Execute(new SetEffectParameterKeyframeCommand(cel.Id, effectId, session.CurrentFrameId, key, value, descriptor));
    }

    public static void ClearEffectParameterKeyframe(this DocumentSession session, EffectInstanceId effectId, string key)
    {
        var cel = ResolveCurrentCel(session);
        var effect = cel.Effects.GetEffect(effectId);
        if (!effect.ParameterTracks.TryGetValue(key, out var track) || !track.Values.ContainsKey(session.CurrentFrameId)) return;
        session.Execute(new ClearEffectParameterKeyframeCommand(cel.Id, effectId, session.CurrentFrameId, key));
    }

    public static void BakeCurrentEffects(this DocumentSession session)
    {
        var snapshot = session.CaptureSnapshot();
        var cel = snapshot.Cels.First(value => value.LayerId == session.CurrentLayerId && value.FrameId == session.CurrentFrameId);
        if (cel.Effects.EffectOrder.Count == 0) return;
        var plan = new EffectBakePlanner(EffectEngine.CreateDefault()).Prepare(snapshot, session.CurrentFrameId, cel);
        session.Execute(new BakeEffectsCommand(plan));
    }

    public static PaletteId AddDefaultPalette(this DocumentSession session)
    {
        var colors = Enumerable.Range(0, 16).Select(i =>
        {
            var v = checked((byte)(255 * i / 15));
            return new Rgba32(v, v, v, 255);
        }).ToArray();
        var command = new AddPaletteCommand(colors);
        session.Execute(command);
        return command.PaletteId;
    }


    public static void MovePaletteColor(this DocumentSession session, PaletteId paletteId, byte index, int delta)
    {
        var palette = session.CaptureSnapshot().GetPalette(paletteId);
        var target = Math.Clamp(index + delta, 0, palette.Count - 1);
        if (target == index) return;
        var order = Enumerable.Range(0, palette.Count).Select(value => checked((byte)value)).ToList();
        var moved = order[index];
        order.RemoveAt(index);
        order.Insert(target, moved);
        session.Execute(new ReorderPaletteCommand(paletteId, order));
    }

    public static TilesetId AddTileset(this DocumentSession session, string name, IntSize tileSize)
    {
        var command = new AddTilesetCommand(name, tileSize);
        session.Execute(command);
        return command.TilesetId;
    }

    public static TileId AddTile(this DocumentSession session, TilesetId tilesetId)
    {
        var command = new AddTileCommand(tilesetId, "Tile");
        session.Execute(command);
        return command.TileId;
    }

    public static TilemapId AddTilemap(this DocumentSession session, string name, TilesetId tilesetId)
    {
        var command = new AddTilemapCommand(name, tilesetId);
        session.Execute(command);
        return command.TilemapId;
    }

    public static IReadOnlyList<TilesetPresentation> GetTilesets(this DocumentSession session)
    {
        var snapshot = session.CaptureSnapshot();
        return snapshot.Tilesets.Values.OrderBy(v => v.Name, StringComparer.Ordinal)
            .Select(v => new TilesetPresentation(v.Id, v.Name, v.TileSize, v.TileOrder.Count)).ToArray();
    }

    public static IReadOnlyList<TilePresentation> GetTiles(this DocumentSession session, TilesetId tilesetId, TileId? current = null)
    {
        var tileset = session.CaptureSnapshot().GetTileset(tilesetId);
        return tileset.TileOrder.Select(id =>
        {
            var tile = tileset.GetTile(id);
            return new TilePresentation(id, tile.Name, tile.SurfaceId, current == id);
        }).ToArray();
    }

    public static IReadOnlyList<TilemapPresentation> GetTilemaps(this DocumentSession session)
    {
        var snapshot = session.CaptureSnapshot();
        return snapshot.Tilemaps.Values.OrderBy(v => v.Name, StringComparer.Ordinal)
            .Select(v => new TilemapPresentation(v.Id, v.Name, v.TilesetId, v.OccupiedCellCount)).ToArray();
    }

    public static void SetTileCell(this DocumentSession session, TilemapId tilemapId, int x, int y, TileId? tileId, TileCellFlags flags = TileCellFlags.None)
    {
        TileCell? cell = tileId is { } id ? new TileCell(id, flags) : null;
        session.Execute(new SetTileCellCommand(tilemapId, new IntPoint(x, y), cell));
    }


    public static void MakeUniqueTile(this DocumentSession session, TilemapId tilemapId, int x, int y) =>
        session.Execute(new MakeUniqueTileCommand(tilemapId, new IntPoint(x, y)));

    public static void CollectUnusedTiles(this DocumentSession session, TilesetId tilesetId) =>
        session.Execute(new CollectUnusedTilesCommand(tilesetId));

    public static TileSurfacePresentation GetTileSurface(this DocumentSession session, TilesetId tilesetId, TileId tileId)
    {
        var snapshot = session.CaptureSnapshot();
        var tile = snapshot.GetTileset(tilesetId).GetTile(tileId);
        var surface = snapshot.GetSurface(tile.SurfaceId);
        return new TileSurfacePresentation(surface.Size, surface.Format, surface.PaletteId, surface.Bytes);
    }

    public static void SetTilePixel(this DocumentSession session, TilesetId tilesetId, TileId tileId, int x, int y, Rgba32 color) =>
        session.Execute(new EditTilePixelsCommand(tilesetId, tileId, [new PixelWrite(x, y, color)]));

    public static void SetIndexedTilePixel(this DocumentSession session, TilesetId tilesetId, TileId tileId, int x, int y, byte index) =>
        session.Execute(new EditTilePixelsCommand(tilesetId, tileId, [new IndexedPixelWrite(x, y, index)]));

    public static IReadOnlyList<AnimationClipPresentation> GetAnimationClips(this DocumentSession session)
    {
        var s = session.CaptureSnapshot();
        return s.Animation.Clips.Select(v => new AnimationClipPresentation(v.Id, v.Name, s.FrameOrder.ToList().IndexOf(v.StartFrameId), s.FrameOrder.ToList().IndexOf(v.EndFrameId), v.LoopMode)).ToArray();
    }

    public static IReadOnlyList<AnimationTagPresentation> GetAnimationTags(this DocumentSession session)
    {
        var s = session.CaptureSnapshot();
        return s.Animation.Tags.Select(v => new AnimationTagPresentation(v.Id, v.Name, s.FrameOrder.ToList().IndexOf(v.StartFrameId), s.FrameOrder.ToList().IndexOf(v.EndFrameId))).ToArray();
    }

    public static AnimationTracksPresentation GetCurrentAnimationTracks(this DocumentSession session)
    {
        var a = session.CaptureSnapshot().Animation;
        var f = session.CurrentFrameId;
        return new AnimationTracksPresentation(
            a.PivotTrack.Values.ContainsKey(f),
            a.HitboxTrack.Values.TryGetValue(f, out var hit) ? hit.Boxes.Count : 0,
            a.HurtboxTrack.Values.TryGetValue(f, out var hurt) ? hurt.Boxes.Count : 0,
            a.SocketTrack.Values.TryGetValue(f, out var sockets) ? sockets.Sockets.Count : 0,
            a.EventTrack.Values.TryGetValue(f, out var events) ? events.Events.Count : 0,
            a.ColorCycleTrack.Values.TryGetValue(f, out var cycles) ? cycles.Cycles.Count : 0);
    }

    public static AnimationClipId AddAnimationClip(this DocumentSession session, string name, int start, int end, AnimationLoopMode loopMode)
    {
        var s = session.CaptureSnapshot();
        start = Math.Clamp(start, 0, s.FrameOrder.Count - 1);
        end = Math.Clamp(end, start, s.FrameOrder.Count - 1);
        var clip = new AnimationClip(AnimationClipId.New(), name, s.FrameOrder[start], s.FrameOrder[end], loopMode);
        session.Execute(new UpsertAnimationClipCommand(clip));
        return clip.Id;
    }

    public static void RemoveAnimationClip(this DocumentSession session, AnimationClipId id) => session.Execute(new RemoveAnimationClipCommand(id));

    public static void UpdateAnimationClip(this DocumentSession session, AnimationClipId id, string name, int start, int end, AnimationLoopMode loopMode)
    {
        var s = session.CaptureSnapshot();
        start = Math.Clamp(start, 0, s.FrameOrder.Count - 1);
        end = Math.Clamp(end, start, s.FrameOrder.Count - 1);
        session.Execute(new UpsertAnimationClipCommand(new AnimationClip(id, name, s.FrameOrder[start], s.FrameOrder[end], loopMode)));
    }

    public static void UpdateAnimationTag(this DocumentSession session, AnimationTagId id, string name, int start, int end)
    {
        var s = session.CaptureSnapshot();
        start = Math.Clamp(start, 0, s.FrameOrder.Count - 1);
        end = Math.Clamp(end, start, s.FrameOrder.Count - 1);
        session.Execute(new UpsertAnimationTagCommand(new AnimationTag(id, name, s.FrameOrder[start], s.FrameOrder[end])));
    }

    public static AnimationTagId AddAnimationTag(this DocumentSession session, string name, int start, int end)
    {
        var s = session.CaptureSnapshot();
        start = Math.Clamp(start, 0, s.FrameOrder.Count - 1);
        end = Math.Clamp(end, start, s.FrameOrder.Count - 1);
        var tag = new AnimationTag(AnimationTagId.New(), name, s.FrameOrder[start], s.FrameOrder[end]);
        session.Execute(new UpsertAnimationTagCommand(tag));
        return tag.Id;
    }

    public static void RemoveAnimationTag(this DocumentSession session, AnimationTagId id) => session.Execute(new RemoveAnimationTagCommand(id));

    public static void SetPivot(this DocumentSession session, int x, int y) => session.Execute(new SetPivotKeyframeCommand(session.CurrentFrameId, new IntPoint(x, y)));
    public static void ClearPivot(this DocumentSession session)
    {
        if (session.CaptureSnapshot().Animation.PivotTrack.Values.ContainsKey(session.CurrentFrameId))
            session.Execute(new ClearPivotKeyframeCommand(session.CurrentFrameId));
    }

    public static void SetHitbox(this DocumentSession session, string name, int x, int y, int width, int height) =>
        session.Execute(new SetHitboxesKeyframeCommand(session.CurrentFrameId, new BoxFrameValue([new NamedBox(name, new IntRect(x, y, width, height))])));

    public static void ClearHitboxes(this DocumentSession session)
    {
        if (session.CaptureSnapshot().Animation.HitboxTrack.Values.ContainsKey(session.CurrentFrameId))
            session.Execute(new ClearHitboxesKeyframeCommand(session.CurrentFrameId));
    }

    public static void SetHurtbox(this DocumentSession session, string name, int x, int y, int width, int height) =>
        session.Execute(new SetHurtboxesKeyframeCommand(session.CurrentFrameId, new BoxFrameValue([new NamedBox(name, new IntRect(x, y, width, height))])));

    public static void ClearHurtboxes(this DocumentSession session)
    {
        if (session.CaptureSnapshot().Animation.HurtboxTrack.Values.ContainsKey(session.CurrentFrameId))
            session.Execute(new ClearHurtboxesKeyframeCommand(session.CurrentFrameId));
    }

    public static void SetSocket(this DocumentSession session, string name, int x, int y) =>
        session.Execute(new SetSocketsKeyframeCommand(session.CurrentFrameId, new SocketFrameValue([new SocketPose(name, new IntPoint(x, y))])));

    public static void ClearSockets(this DocumentSession session)
    {
        if (session.CaptureSnapshot().Animation.SocketTrack.Values.ContainsKey(session.CurrentFrameId))
            session.Execute(new ClearSocketsKeyframeCommand(session.CurrentFrameId));
    }

    public static void SetAnimationEvent(this DocumentSession session, string name, string payload) =>
        session.Execute(new SetAnimationEventsKeyframeCommand(session.CurrentFrameId, new EventFrameValue([new AnimationEventMarker(name, payload)])));

    public static void ClearAnimationEvents(this DocumentSession session)
    {
        if (session.CaptureSnapshot().Animation.EventTrack.Values.ContainsKey(session.CurrentFrameId))
            session.Execute(new ClearAnimationEventsKeyframeCommand(session.CurrentFrameId));
    }

    public static void SetColorCycle(this DocumentSession session, PaletteId paletteId, byte start, byte end, int offset) =>
        session.Execute(new SetColorCyclesKeyframeCommand(session.CurrentFrameId, new ColorCycleFrameValue([new PaletteCycle(paletteId, start, end, offset)])));

    public static void ClearColorCycles(this DocumentSession session)
    {
        if (session.CaptureSnapshot().Animation.ColorCycleTrack.Values.ContainsKey(session.CurrentFrameId))
            session.Execute(new ClearColorCyclesKeyframeCommand(session.CurrentFrameId));
    }

    public static IReadOnlyList<SpriteSlice> GetSpriteSlices(this DocumentSession session) => session.CaptureSnapshot().Animation.Slices;

    public static SliceId AddSpriteSlice(this DocumentSession session, string name, int x, int y, int width, int height, int pivotX, int pivotY)
    {
        var slice = new SpriteSlice(SliceId.New(), name, new IntRect(x, y, width, height), new IntPoint(pivotX, pivotY));
        session.Execute(new UpsertSpriteSliceCommand(slice));
        return slice.Id;
    }

    public static void RemoveSpriteSlice(this DocumentSession session, SliceId id) => session.Execute(new RemoveSpriteSliceCommand(id));

    public static void UpdateSpriteSlice(this DocumentSession session, SliceId id, string name, int x, int y, int width, int height, int pivotX, int pivotY, NineSliceInsets? nineSlice)
    {
        var slice = new SpriteSlice(id, name, new IntRect(x, y, width, height), new IntPoint(pivotX, pivotY), nineSlice);
        session.Execute(new UpsertSpriteSliceCommand(slice));
    }

    public static CanvasPresentation RenderCanvasWithOnionSkin(this DocumentSession session, OnionSkinPresentationSettings settings)
    {
        ArgumentNullException.ThrowIfNull(session);
        ArgumentNullException.ThrowIfNull(settings);
        var current = session.RenderCanvas();
        var snapshot = session.CaptureSnapshot();
        var onion = new OnionSkinRenderer(new FrameRenderer()).Render(
            snapshot,
            new FrameRenderRequest(session.CurrentFrameId),
            new OnionSkinSettings(settings.PreviousFrames, settings.NextFrames, settings.Opacity, settings.DepthFalloff));
        return new CanvasPresentation(
            current.FrameId,
            current.Size,
            onion.Surface.Bytes,
            current.PreviewPixels,
            current.DirtyRegions,
            current.Diagnostics);
    }

    public static DocumentSession ImportPng(this EditorWorkspace workspace, string path)
    {
        ArgumentNullException.ThrowIfNull(workspace);
        ArgumentException.ThrowIfNullOrWhiteSpace(path);
        var fullPath = Path.GetFullPath(path);
        var document = ImportPipeline.CreateDefault().Execute(
            BuiltinImporterIds.Png,
            new ImportRequest(Path.GetFileName(fullPath), File.ReadAllBytes(fullPath)));
        return workspace.OpenRecovered(new PixelProject(document), fullPath, $"import-{Guid.NewGuid():N}");
    }

    private static CelSnapshot ResolveCurrentCel(DocumentSession session)
    {
        ArgumentNullException.ThrowIfNull(session);
        return session.CaptureSnapshot().Cels.FirstOrDefault(v => v.LayerId == session.CurrentLayerId && v.FrameId == session.CurrentFrameId)
            ?? throw new InvalidOperationException("Current Layer/Frame has no Cel.");
    }
}

public sealed class SelectionWorkspaceRuntime
{
    private sealed record State(ResourceId SurfaceId, IntPoint Origin, SelectionMask Mask);
    private readonly ConditionalWeakTable<DocumentSession, Holder> _states = new();
    private sealed class Holder { public State? Value; }

    public SelectionOverlayPresentation? GetOverlay(DocumentSession session)
    {
        if (!_states.TryGetValue(session, out var holder) || holder.Value is not { } state || state.Mask.IsEmpty) return null;
        var b = state.Mask.Bounds;
        var pixels = state.Mask.EnumerateSelected()
            .Select(point => new IntPoint(point.X + state.Origin.X, point.Y + state.Origin.Y))
            .ToArray();
        return new SelectionOverlayPresentation(
            new IntRect(b.X + state.Origin.X, b.Y + state.Origin.Y, b.Width, b.Height),
            pixels);
    }

    public void SelectRectangle(DocumentSession session, int ax, int ay, int bx, int by)
    {
        var target = Resolve(session);
        var left = Math.Min(ax, bx) - target.Origin.X;
        var top = Math.Min(ay, by) - target.Origin.Y;
        var right = Math.Max(ax, bx) - target.Origin.X;
        var bottom = Math.Max(ay, by) - target.Origin.Y;
        var bounds = new IntRect(left, top, right - left + 1, bottom - top + 1);
        var mask = SelectionFactory.Rectangle(target.Surface.Size, bounds);
        _states.GetOrCreateValue(session).Value = new State(target.Cel.SurfaceId, target.Origin, mask);
    }


    public void SelectEllipse(DocumentSession session, int ax, int ay, int bx, int by)
    {
        var target = Resolve(session);
        var left = Math.Min(ax, bx) - target.Origin.X;
        var top = Math.Min(ay, by) - target.Origin.Y;
        var right = Math.Max(ax, bx) - target.Origin.X;
        var bottom = Math.Max(ay, by) - target.Origin.Y;
        var mask = SelectionFactory.Ellipse(target.Surface.Size, new IntRect(left, top, right - left + 1, bottom - top + 1));
        _states.GetOrCreateValue(session).Value = new State(target.Cel.SurfaceId, target.Origin, mask);
    }

    public void SelectLasso(DocumentSession session, IReadOnlyList<IntPoint> canvasVertices)
    {
        ArgumentNullException.ThrowIfNull(canvasVertices);
        if (canvasVertices.Count < 3) return;
        var target = Resolve(session);
        var local = canvasVertices.Select(point => new IntPoint(point.X - target.Origin.X, point.Y - target.Origin.Y)).ToArray();
        var mask = SelectionFactory.Lasso(target.Surface.Size, local);
        _states.GetOrCreateValue(session).Value = new State(target.Cel.SurfaceId, target.Origin, mask);
    }

    public void SelectByColor(DocumentSession session, int canvasX, int canvasY)
    {
        var target = Resolve(session);
        var x = canvasX - target.Origin.X;
        var y = canvasY - target.Origin.Y;
        if ((uint)x >= (uint)target.Surface.Size.Width || (uint)y >= (uint)target.Surface.Size.Height) return;
        var reference = target.Surface.GetPixel(x, y);
        var mask = SelectionFactory.ByColor(target.Surface, reference);
        _states.GetOrCreateValue(session).Value = new State(target.Cel.SurfaceId, target.Origin, mask);
    }

    public void SelectAll(DocumentSession session)
    {
        var target = Resolve(session);
        var mask = SelectionFactory.Rectangle(target.Surface.Size, new IntRect(0, 0, target.Surface.Size.Width, target.Surface.Size.Height));
        _states.GetOrCreateValue(session).Value = new State(target.Cel.SurfaceId, target.Origin, mask);
    }

    public void Clear(DocumentSession session) => _states.GetOrCreateValue(session).Value = null;

    public void Invert(DocumentSession session)
    {
        var state = Require(session);
        _states.GetOrCreateValue(session).Value = state with { Mask = SelectionMaskOperations.Invert(state.Mask) };
    }

    public void Move(DocumentSession session, int dx, int dy)
    {
        var state = Require(session);
        var delta = new IntPoint(dx, dy);
        var surface = session.Document.Resources.GetSurface(state.SurfaceId).Snapshot();
        var patch = FloatingContentComposer.BuildMovePatch(surface, state.Mask, delta);
        if (!patch.IsEmpty) session.Execute(new PixelPatchCommand(state.SurfaceId, patch.Writes, "Move Selection"));
        _states.GetOrCreateValue(session).Value = state with { Mask = SelectionTransforms.Translate(state.Mask, delta) };
    }


    public void Scale(DocumentSession session, int width, int height)
    {
        if (width <= 0 || height <= 0) throw new ArgumentOutOfRangeException(nameof(width));
        var state = Require(session);
        var surface = session.Document.Resources.GetSurface(state.SurfaceId).Snapshot();
        var floating = FloatingContent.Capture(surface, state.Mask);
        var transformed = FloatingContentTransforms.ScaleNearest(floating, new IntSize(width, height));
        var patch = FloatingContentComposer.BuildTransformPatch(surface, state.Mask, transformed);
        if (!patch.IsEmpty) session.Execute(new PixelPatchCommand(state.SurfaceId, patch.Writes, "Scale Selection"));
        var bounds = state.Mask.Bounds;
        var mask = SelectionTransforms.ScaleNearest(state.Mask, new IntRect(bounds.X, bounds.Y, width, height));
        _states.GetOrCreateValue(session).Value = state with { Mask = mask };
    }

    public void FlipHorizontal(DocumentSession session) => Transform(session, FloatingContentTransforms.FlipHorizontal, SelectionTransforms.FlipHorizontal, "Flip Selection H");
    public void FlipVertical(DocumentSession session) => Transform(session, FloatingContentTransforms.FlipVertical, SelectionTransforms.FlipVertical, "Flip Selection V");
    public void RotateClockwise(DocumentSession session) => Transform(session, value => FloatingContentTransforms.Rotate90(value, QuarterTurn.Clockwise), value => SelectionTransforms.Rotate90(value, QuarterTurn.Clockwise), "Rotate Selection");

    private void Transform(DocumentSession session, Func<FloatingContent, FloatingContent> contentTransform, Func<SelectionMask, SelectionMask> maskTransform, string name)
    {
        var state = Require(session);
        var surface = session.Document.Resources.GetSurface(state.SurfaceId).Snapshot();
        var floating = FloatingContent.Capture(surface, state.Mask);
        var transformed = contentTransform(floating);
        var patch = FloatingContentComposer.BuildTransformPatch(surface, state.Mask, transformed);
        if (!patch.IsEmpty) session.Execute(new PixelPatchCommand(state.SurfaceId, patch.Writes, name));
        _states.GetOrCreateValue(session).Value = state with { Mask = maskTransform(state.Mask) };
    }

    private State Require(DocumentSession session) => _states.TryGetValue(session, out var holder) && holder.Value is { } state
        ? state
        : throw new InvalidOperationException("No selection.");

    private static (CelSnapshot Cel, PixelSurfaceSnapshot Surface, IntPoint Origin) Resolve(DocumentSession session)
    {
        var snapshot = session.CaptureSnapshot();
        var cel = snapshot.Cels.FirstOrDefault(v => v.LayerId == session.CurrentLayerId && v.FrameId == session.CurrentFrameId)
            ?? throw new InvalidOperationException("Current Layer/Frame has no Cel.");
        return (cel, snapshot.GetSurface(cel.SurfaceId), cel.Position);
    }
}

public sealed class PlaybackWorkspaceRuntime
{
    private readonly ConditionalWeakTable<DocumentSession, ClockHolder> _clocks = new();
    private sealed class ClockHolder { public AnimationPlaybackClock Clock { get; } = new(); }

    public bool IsPlaying(DocumentSession session) => _clocks.TryGetValue(session, out var holder) && holder.Clock.IsConfigured && holder.Clock.IsPlaying;

    public void Toggle(DocumentSession session)
    {
        var clock = _clocks.GetOrCreateValue(session).Clock;
        if (!clock.IsConfigured)
        {
            clock.Configure(session.CaptureSnapshot(), startFrameId: session.CurrentFrameId, autoplay: true);
            return;
        }
        if (clock.IsPlaying) clock.Pause();
        else
        {
            clock.Configure(session.CaptureSnapshot(), startFrameId: session.CurrentFrameId, autoplay: true);
        }
    }

    public bool Advance(DocumentSession session, long microseconds)
    {
        if (!_clocks.TryGetValue(session, out var holder) || !holder.Clock.IsConfigured || !holder.Clock.IsPlaying) return false;
        var next = holder.Clock.Advance(microseconds);
        if (next == session.CurrentFrameId) return false;
        session.SelectFrame(next);
        return true;
    }

    public void Stop(DocumentSession session)
    {
        if (_clocks.TryGetValue(session, out var holder) && holder.Clock.IsConfigured) holder.Clock.Pause();
    }
}

